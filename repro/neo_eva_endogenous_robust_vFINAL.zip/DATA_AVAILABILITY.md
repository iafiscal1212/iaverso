# Data Availability

Aggregated figures and statistics only.
No raw traces, no implementation code.

Additional results available under NDA/license.

Contact: [redacted]
